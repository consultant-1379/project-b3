package com.ericsson.nativecloud.model;

public class SurveyUserDTO {
    int userId;
    String userName;
    String userEmail;
}
