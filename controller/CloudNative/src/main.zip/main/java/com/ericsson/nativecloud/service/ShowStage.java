package com.ericsson.nativecloud.service;

public interface ShowStage {
    String getStageName(int sId);
}
